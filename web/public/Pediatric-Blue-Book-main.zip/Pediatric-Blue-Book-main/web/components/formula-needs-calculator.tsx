// File: web/components/formula-needs-calculator.tsx
// Component for creating custom formula recipes by mixing multiple ingredients (powders, liquids, supplements).
// Calculates nutritional content of combined ingredients, compares to ideal nutrient needs, and generates PDF summaries.

import { CheckSquare, Ellipsis, Plus, Square, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import Popup from "./pop-up";
import { supabase } from "@/lib/supabase";
import type { ProductRow, Ingredient } from "@/lib/types";
import CalorieCircle from "./calorie-circle";
import FormulaDocument from "./formula-summary";
import { pdf } from "@react-pdf/renderer";

// Type definition for nutrient data structure
type Nutrient = {
  name: string;
  amount: string;
};

// Type definition for selected ingredient in formula recipe
type SelectedIngredient = {
  name: string;
  type: string;
  amount: string;
  row?: ProductRow;
};

// Props interface for FormulaNeedsCalculator component
interface FormulaNeedsCalculatorProps {
  idealNutrients?: Nutrient[]; // Optional array of ideal nutrient values from nutrient needs calculator
}

const FormulaNeedsCalculator = ({
  idealNutrients = [],
}: FormulaNeedsCalculatorProps) => {
  const [popUp, setPopUp] = useState(false);
  const [selectedIngredientForPopup, setSelectedIngredientForPopup] =
    useState<Ingredient | null>(null);

  const [search, setSearch] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const WATER_INGREDIENT: Ingredient = { name: "Water", type: "Liquid" };
  const [ingredients, setIngredients] = useState<Ingredient[]>([
    WATER_INGREDIENT,
  ]);
  const [selectedIngredients, setSelectedIngredients] = useState<
    SelectedIngredient[]
  >([]);
  const [servings, setServings] = useState<number>(1);
  // Tracks if formula summary PDF is being generated
  const [isGenerating, setIsGenerating] = useState(false);
  // Tracks if user has started adding ingredients for PDF generation
  const [hasMixed, setHasMixed] = useState(false);

  // Effect: Fetches all active powder and liquid ingredients from database on component mount
  useEffect(() => {
    // Function: Retrieves active powder and liquid products from Supabase and stores as available ingredients
    const getIngredients = async () => {
      // fetch rows for powder and liquid
      const [powderRes, liquidRes] = await Promise.all([
        supabase.from("powder_ingredient").select("*").eq("active", true),
        supabase.from("liquid_ingredient").select("*").eq("active", true),
      ]);
      if (powderRes.error)
        console.error("powder_ingredients error:", powderRes.error);
      if (liquidRes.error)
        console.error("liquid_ingredients error:", liquidRes.error);

      const powderRows: ProductRow[] = (powderRes.data ?? []) as ProductRow[];
      const liquidRows: ProductRow[] = (liquidRes.data ?? []) as ProductRow[];

      const fetched: Ingredient[] = [
        ...powderRows.map((r) => ({
          name: (r.product ?? "").toString().trim(),
          type: "Powder",
          row: r,
        })),
        ...liquidRows.map((r) => ({
          name: (r.product ?? "").toString().trim(),
          type: "Liquid",
          row: r,
        })),
      ].filter((it) => it.name.length > 0);

      setIngredients((prev) => {
        const map = new Map<string, Ingredient>();
        [...prev, WATER_INGREDIENT, ...fetched].forEach((item) =>
          map.set(item.name.toLowerCase(), item)
        );
        return Array.from(map.values());
      });
    };

    getIngredients();
  }, []);

  // Extract minimum gram amount for Protein, Carbohydrates, and Fats
  const extractMinGrams = (amountString: string): string => {
    if (!amountString) return "";

    // Handle formats like:
    // - "≥ 15 g (1.5 g/kg)" -> extract "15 g"
    // - "15 - 25 g" -> extract "15 g" (first number, lower end of range)
    // - "15 g" -> extract "15 g"
    // - "15.5 - 25.2 g" -> extract "15.5 g"

    // First, try to match range format "X - Y g" or "X-Y g"
    const rangeMatch = amountString.match(
      /(\d+(?:\.\d+)?)\s*-\s*\d+(?:\.\d+)?\s*g/
    );
    if (rangeMatch) {
      return rangeMatch[1] + " g";
    }

    // Then try to match any format with number followed by "g"
    const match = amountString.match(/(\d+(?:\.\d+)?)\s*g/);
    if (match) {
      return match[1] + " g";
    }

    return amountString; // Fallback to original if pattern doesn't match
  };

  // Extract just calories from Energy Needs string
  const extractCalories = (amountString: string): string => {
    if (!amountString) return "";

    // Handle format like "1500 cal (100 cal/kg)" -> extract "1500 cal"
    const match = amountString.match(/(\d+(?:\.\d+)?)\s*cal/);
    if (match) {
      return match[1] + " cal";
    }

    return amountString; // Fallback to original if pattern doesn't match
  };

  // Parse numeric value from amount string (handles various formats)
  const parseAmountValue = (amountString: string): number | null => {
    if (!amountString) return null;

    // Extract the first number (can be decimal)
    const match = amountString.match(/(\d+(?:\.\d+)?)/);
    if (match) {
      return parseFloat(match[1]);
    }
    return null;
  };

  // Format ideal amount based on nutrient type and divide by servings
  const formatIdealAmount = (
    nutrientName: string,
    idealAmount: string
  ): string => {
    if (!idealAmount) return "";

    let formatted: string;

    // For Energy Needs, extract just the calories
    if (nutrientName === "Calories") {
      formatted = extractCalories(idealAmount);
    }
    // For Protein, Carbohydrates, and Fats, extract just the minimum gram amount
    else if (
      nutrientName === "Protein" ||
      nutrientName === "Carbohydrates" ||
      nutrientName === "Fats"
    ) {
      formatted = extractMinGrams(idealAmount);
    }
    // For all other nutrients, return the full string
    else {
      formatted = idealAmount;
    }

    // Divide by servings if servings > 1
    if (formatted) {
      const numericValue = parseAmountValue(formatted);
      if (numericValue !== null) {
        const dividedValue = numericValue;

        // Extract unit - everything after the first number (with optional whitespace)
        const unitMatch = formatted.match(/\d+(?:\.\d+)?\s*(.+)$/);
        const unit = unitMatch ? unitMatch[1].trim() : "";

        // Format to reasonable decimal places
        const roundedValue = Math.round(dividedValue * 10) / 10;
        return `${roundedValue}${unit ? " " + unit : ""}`;
      }
    }

    return formatted;
  };

  // Generate nutrients list dynamically from idealNutrients or use a default structure
  // This ensures we show all nutrients that match the nutrient needs calculator
  const nutrients =
    idealNutrients.length > 0
      ? idealNutrients
          .filter((n) => n.name !== "" && n.amount !== "") // Filter out empty entries
          .map((n) => ({ name: n.name, amount: "" })) // Start with empty amounts (will be calculated from formulas)
      : [
          { name: "Calories", amount: "" },
          { name: "Holliday-Segar", amount: "" },
          { name: "DRI Fluid", amount: "" },
          { name: "Protein", amount: "" },
          { name: "Carbohydrates", amount: "" },
          { name: "Fats", amount: "" },
          { name: "Fiber (DGA)", amount: "" },
          { name: "Calcium", amount: "" },
          { name: "Iron", amount: "" },
          { name: "Vitamin D", amount: "" },
          { name: "Potassium", amount: "" },
          { name: "Magnesium", amount: "" },
          { name: "Zinc", amount: "" },
          { name: "Vitamin A", amount: "" },
          { name: "Vitamin E", amount: "" },
          { name: "Vitamin C", amount: "" },
          { name: "Vitamin K", amount: "" },
          { name: "Thiamin", amount: "" },
          { name: "Riboflavin", amount: "" },
          { name: "Niacin", amount: "" },
          { name: "Vitamin B6", amount: "" },
          { name: "Folate", amount: "" },
          { name: "Vitamin B12", amount: "" },
          { name: "Pantothenic Acid", amount: "" },
          { name: "Biotin", amount: "" },
          { name: "Choline", amount: "" },
          { name: "Chromium", amount: "" },
          { name: "Copper", amount: "" },
          { name: "Fluoride", amount: "" },
          { name: "Iodine", amount: "" },
          { name: "Manganese", amount: "" },
          { name: "Phosphorus", amount: "" },
          { name: "Selenium", amount: "" },
          { name: "Sodium", amount: "" },
          { name: "Chloride", amount: "" },
        ];

  const filteredIngredients = ingredients.filter(
    (ingredient) =>
      (ingredient.type === filter || filter === "All") &&
      ingredient.name.toLowerCase().includes(query.toLowerCase())
  );

  const [checked, setChecked] = useState<boolean[]>(
    Array(selectedIngredients.length).fill(false)
  );

  const toggleCheck = (index: number) => {
    setChecked((prev) => prev.map((val, i) => (i === index ? !val : val)));
  };

  const handleAddIngredient = (
    ingredient: Ingredient,
    amount: string,
    servingType: string
  ) => {
    const newIngredient: SelectedIngredient = {
      name: ingredient.name,
      type: ingredient.type,
      amount: `${amount} ${servingType}`,
      row: ingredient.row,
    };
    setSelectedIngredients((prev) => [...prev, newIngredient]);
    setChecked((prev) => [...prev, false]);
    setPopUp(false);
    setSelectedIngredientForPopup(null);
    setHasMixed(true);
  };

  const handlePlusClick = (ingredient: Ingredient) => {
    setSelectedIngredientForPopup(ingredient);
    setPopUp(true);
  };

  const handleEllipsisClick = (selectedIngredient: SelectedIngredient) => {
    // Create an Ingredient object from the SelectedIngredient
    const ingredient: Ingredient = {
      name: selectedIngredient.name,
      type: selectedIngredient.type,
      row: selectedIngredient.row,
    };
    setSelectedIngredientForPopup(ingredient);
    setPopUp(true);
  };

  const parseAmount = (
    amountString: string
  ): { amount: string; servingType: string } => {
    // Parse "2 Scoop" or "1 Cup" format
    const parts = amountString.trim().split(" ");
    if (parts.length >= 2) {
      return {
        amount: parts[0],
        servingType: parts.slice(1).join(" "),
      };
    }
    return { amount: "1", servingType: "Scoop" };
  };

  // Convert serving to grams (for powder) or ml (for liquid)
  const isWaterIngredient = (ingredient: { name: string }) =>
    ingredient.name.toLowerCase() === "water";

  const getGramsOrMl = (ingredient: SelectedIngredient): number => {
    const isWater = isWaterIngredient(ingredient);
    const parsed = parseAmount(ingredient.amount);
    const quantity = parseFloat(parsed.amount) || 0;
    const servingType = parsed.servingType;

    if (isWater) {
      const mlPerServing =
        servingType == "mL"
          ? 1
          : servingType == "oz"
          ? 29.57
          : servingType === "Cup"
          ? 236.6
          : servingType === "Tablespoon"
          ? 14.8
          : servingType === "Teaspoon"
          ? 4.9
          : 0;
      return quantity * mlPerServing;
    }

    const row = ingredient.row;
    if (!row) return 0;

    if (ingredient.type === "Powder") {
      // Powder: use grams_per_* values
      const gramsPerServing =
        servingType === "Scoop"
          ? (row.grams_per_scoop as number) || 0
          : servingType === "Teaspoon"
          ? (row.grams_per_teaspoon as number) || 0
          : servingType === "Tablespoon"
          ? (row.grams_per_tablespoon as number) || 0
          : servingType === "Cup"
          ? (row.grams_per_cup as number) || 0
          : 0;

      // For np100 (per 100ml), we need to convert grams to ml of prepared formula
      // Assuming standard reconstitution: typically 1 scoop (8.5g) makes ~60ml
      // We can estimate using calories_per_gram if available, or use a standard ratio

      // If we have calories_per_gram, we can estimate prepared volume
      // Standard formula is ~20 cal/oz = ~0.67 cal/ml, so ml = calories / 0.67
      // Or: if calories_per_gram = 5, then 8.5g = 42.5 cal, prepared = 42.5/0.67 = 63ml

      return Math.round(gramsPerServing * quantity);
    } else {
      // Liquid: convert serving type to ml
      const mlPerServing =
        servingType == "mL"
          ? 1
          : servingType == "oz"
          ? 29.57
          : servingType === "Cup"
          ? 236.6 // US cup = 236.6ml
          : servingType === "Tablespoon"
          ? 14.8 // 1 tbsp = 14.8ml
          : servingType === "Teaspoon"
          ? 4.9 // 1 tsp = 4.9ml
          : 0;

      return quantity * mlPerServing;
    }
  };

  const getVolume = (ingredient: SelectedIngredient): number => {
    const isWater = isWaterIngredient(ingredient);
    const parsed = parseAmount(ingredient.amount);
    const quantity = parseFloat(parsed.amount) || 0;
    const servingType = parsed.servingType;

    if (isWater) {
      const mlPerServing =
        servingType == "mL"
          ? 1
          : servingType == "oz"
          ? 29.57
          : servingType === "Cup"
          ? 236.6
          : servingType === "Tablespoon"
          ? 14.8
          : servingType === "Teaspoon"
          ? 4.9
          : 0;
      return quantity * mlPerServing;
    }

    const row = ingredient.row;
    if (!row) return 0;

    if (ingredient.type === "Powder") {
      // Powder: use grams_per_* values
      const gramsPerServing =
        servingType === "Scoop"
          ? (row.grams_per_scoop as number) || 0
          : servingType === "Teaspoon"
          ? (row.grams_per_teaspoon as number) || 0
          : servingType === "Tablespoon"
          ? (row.grams_per_tablespoon as number) || 0
          : servingType === "Cup"
          ? (row.grams_per_cup as number) || 0
          : 0;
      const displacementMlPerGram = (row.displacement_ml_per_g as number) || 0;

      // For np100 (per 100ml), we need to convert grams to ml of prepared formula
      // Assuming standard reconstitution: typically 1 scoop (8.5g) makes ~60ml
      // We can estimate using calories_per_gram if available, or use a standard ratio

      // If we have calories_per_gram, we can estimate prepared volume
      // Standard formula is ~20 cal/oz = ~0.67 cal/ml, so ml = calories / 0.67
      // Or: if calories_per_gram = 5, then 8.5g = 42.5 cal, prepared = 42.5/0.67 = 63ml

      return Math.round(displacementMlPerGram * gramsPerServing * quantity);
    } else {
      // Liquid: convert serving type to ml
      const mlPerServing =
        servingType == "mL"
          ? 1
          : servingType == "oz"
          ? 29.57
          : servingType === "Cup"
          ? 236.6 // US cup = 236.6ml
          : servingType === "Tablespoon"
          ? 14.8 // 1 tbsp = 14.8ml
          : servingType === "Teaspoon"
          ? 4.9 // 1 tsp = 4.9ml
          : 0;

      return quantity * mlPerServing;
    }
  };

  // Calculate nutrients from all selected ingredients
  const calculateNutrients = (): Record<string, number> => {
    const totals: Record<string, number> = {};

    selectedIngredients.forEach((ingredient) => {
      const isWater = isWaterIngredient(ingredient);
      const row = ingredient.row;
      if (!row && !isWater) return;

      const mlPrepared = getGramsOrMl(ingredient);
      const parsedAmount = parseAmount(ingredient.amount);
      const quantity = parseFloat(parsedAmount.amount) || 0;
      const servingType = parsedAmount.servingType;

      if (isWater) {
        if (mlPrepared > 0) {
          if (!totals["Holliday-Segar"]) totals["Holliday-Segar"] = 0;
          totals["Holliday-Segar"] += mlPrepared;
          if (!totals["DRI Fluid"]) totals["DRI Fluid"] = 0;
          totals["DRI Fluid"] += mlPrepared;
        }
        return;
      }

      if (!row) return;

      if (ingredient.type === "Powder") {
        // For powder: np100 values are per 100 kcal
        // First calculate the total calories from this ingredient
        const caloriesPerGram = (row.calories_per_gram as number) || 0;
        const gramsPerServing =
          servingType === "Scoop"
            ? (row.grams_per_scoop as number) || 0
            : servingType === "Teaspoon"
            ? (row.grams_per_teaspoon as number) || 0
            : servingType === "Tablespoon"
            ? (row.grams_per_tablespoon as number) || 0
            : servingType === "Cup"
            ? (row.grams_per_cup as number) || 0
            : 0;
        const totalGrams = gramsPerServing * quantity;
        const calories = totalGrams * caloriesPerGram;

        // Scale factor: np100 values are per 100 kcal, so divide calories by 100
        const scaleFactor = calories / 100;

        // Map nutrient names to np100 column names
        const nutrientMap: Record<string, string> = {
          Protein: "np100_total_protein_g",
          Carbohydrates: "np100_total_carbohydrate_g",
          Fats: "np100_total_fat_g",
          Calcium: "np100_calcium_mg",
          Iron: "np100_iron_mg",
          "Vitamin D": "np100_vitamin_d_mcg",
          Potassium: "np100_potassium_mg",
          Magnesium: "np100_magnesium_mg",
          Zinc: "np100_zinc_mg",
          "Vitamin A": "np100_vitamin_a_mcg_re",
          "Vitamin E": "np100_vitamin_e_mg",
          "Vitamin C": "np100_vitamin_c_mg",
          "Vitamin K": "np100_vitamin_k_mcg",
          Thiamin: "np100_thiamin_mg",
          Riboflavin: "np100_riboflavin_mg",
          Niacin: "np100_niacin_mg",
          "Vitamin B6": "np100_b6_mg",
          Folate: "np100_folic_acid_mcg",
          "Vitamin B12": "np100_b12_mcg",
          "Pantothenic Acid": "np100_pantothenic_acid_mg",
          Biotin: "np100_biotin_mcg",
          Choline: "np100_choline_mg",
          Chromium: "np100_chromium_mcg",
          Copper: "np100_copper_mg",
          Fluoride: "np100_fluoride_mg",
          Iodine: "np100_iodine_mcg",
          Manganese: "np100_manganese_mg",
          Phosphorus: "np100_phosphorus_mg",
          Selenium: "np100_selenium_mcg",
          Sodium: "np100_sodium_mg",
          Chloride: "np100_chloride_mg",
          "Fiber (DGA)": "np100_fiber_g",
        };

        Object.entries(nutrientMap).forEach(([nutrientName, columnName]) => {
          if (!ingredient.row) return;
          const value = ingredient.row[columnName] as number;
          if (value != null && !isNaN(value)) {
            if (!totals[nutrientName]) totals[nutrientName] = 0;
            totals[nutrientName] += value * scaleFactor;
          }
        });

        if (calories > 0) {
          if (!totals["Calories"]) totals["Calories"] = 0;
          totals["Calories"] += calories;
        }
      } else {
        const caloriesPerMl = (row.calories_per_ml as number) || 0;

        // For liquid: npc values are per container
        const amountPerCarton = (row.amount_per_carton_ml as number) || 1;
        const multiplier = mlPrepared / amountPerCarton;

        const nutrientMap: Record<string, string> = {
          Protein: "total_protein_g",
          Carbohydrates: "total_carbohydrate_g",
          Fats: "total_fat_g",
          "Fiber (DGA)": "npc_fiber_g",
          Calcium: "npc_calcium_mg",
          Iron: "npc_iron_mg",
          "Vitamin D": "npc_vitamin_d_mcg",
          Potassium: "npc_potassium_mg",
          Magnesium: "npc_magnesium_mg",
          Zinc: "npc_zinc_mg",
          "Vitamin A": "npc_vitamin_a_mcg",
          "Vitamin E": "npc_vitamin_e_mg",
          "Vitamin C": "npc_vitamin_c_mg",
          "Vitamin K": "npc_vitamin_k_mcg",
          Thiamin: "npc_thiamin_mg",
          Riboflavin: "npc_riboflavin_mg",
          Niacin: "npc_niacin_mg",
          "Vitamin B6": "npc_b6_mg",
          Folate: "npc_folic_acid_mcg",
          "Vitamin B12": "npc_b12_mcg",
          "Pantothenic Acid": "npc_pantothenic_acid_mg",
          Biotin: "npc_biotin_mcg",
          Choline: "npc_choline_mg",
          Chromium: "npc_chromium_mcg",
          Copper: "npc_copper_mg",
          Fluoride: "npc_fluoride_mg",
          Iodine: "npc_iodine_mcg",
          Manganese: "npc_manganese_mg",
          Phosphorus: "npc_phosphorus_mg",
          Selenium: "npc_selenium_mcg",
          Sodium: "npc_sodium_mg",
          Chloride: "npc_chloride_mg",
          "Holliday-Segar": "water_ml",
          "DRI Fluid": "water_ml",
        };

        Object.entries(nutrientMap).forEach(([nutrientName, columnName]) => {
          const value = row[columnName] as number;
          if (value != null && !isNaN(value)) {
            if (!totals[nutrientName]) totals[nutrientName] = 0;
            totals[nutrientName] += value * multiplier;
          }
        });

        const calories = caloriesPerMl * mlPrepared;
        if (calories > 0) {
          if (!totals["Calories"]) totals["Calories"] = 0;
          totals["Calories"] += calories;
        }
      }
    });

    // Multiply by servings per day
    Object.keys(totals).forEach((key) => {
      if (servings > 0) {
        totals[key] = totals[key] * servings;
      }
    });

    return totals;
  };

  const handleDeleteChecked = () => {
    const newSelectedIngredients = selectedIngredients.filter(
      (_, index) => !checked[index]
    );
    const newChecked = newSelectedIngredients.map(() => false);
    setSelectedIngredients(newSelectedIngredients);
    setChecked(newChecked);
  };

  const calculatedNutrients = calculateNutrients();

  const displayedNutrients = nutrients.map((nutrient, index) => {
    const idealNutrient = idealNutrients.find(
      (ideal) => ideal.name === nutrient.name
    );
    const formattedIdeal = idealNutrient
      ? formatIdealAmount(nutrient.name, idealNutrient.amount)
      : "";

    let calculatedValue = calculatedNutrients[nutrient.name] || 0;
    let formattedAmount = "";
    let isBelowThreshold = false;

    if (calculatedValue > 0) {
      // Determine unit
      let unit = "";

      if (nutrient.name === "Calories") unit = "cal";
      else if (
        ["Protein", "Carbohydrates", "Fats", "Fiber (DGA)"].includes(
          nutrient.name
        )
      )
        unit = "g";
      else if (["Holliday-Segar", "DRI Fluid"].includes(nutrient.name)) {
        if (nutrient.name === "DRI Fluid") {
          calculatedValue = calculatedValue / 1000;
        }

        unit = nutrient.name === "DRI Fluid" ? "L" : "mL";
      } else if (
        [
          "Chromium",
          "Iodine",
          "Selenium",
          "Biotin",
          "Folate",
          "Vitamin A",
          "Vitamin D",
          "Vitamin B12",
          "Molybdenum",
          "Vitamin K",
          "Copper",
        ].includes(nutrient.name)
      )
        unit = "mcg";
      else unit = "mg";

      let roundedValue;
      if (nutrient.name === "DRI Fluid") {
        roundedValue = Math.round(calculatedValue * 100) / 100;
      } else if (
        nutrient.name === "Calories" ||
        Number.isInteger(calculatedValue) ||
        nutrient.name === "Reduced Calories" ||
        nutrient.name === "Catch-Up Calories" ||
        nutrient.name === "Holliday-Segar"
      ) {
        roundedValue = Math.round(calculatedValue);
      } else {
        roundedValue = calculatedValue.toFixed(1);
      }
      formattedAmount = `${roundedValue} ${unit}`;

      // Threshold check
      if (formattedIdeal && idealNutrient) {
        const idealNumeric = parseAmountValue(formattedIdeal);
        if (idealNumeric && idealNumeric > 0) {
          const idealUnitMatch = formattedIdeal.match(
            /\d+(?:\.\d+)?\s*(cal|g|mg|mcg|μg|mL|L|RAE|DFE)/i
          );
          const idealUnit = idealUnitMatch
            ? idealUnitMatch[1].toLowerCase()
            : "";

          let calculatedInSameUnit = calculatedValue;
          let idealInSameUnit = idealNumeric;

          if (
            ["Protein", "Carbohydrates", "Fats", "Fiber (DGA)"].includes(
              nutrient.name
            )
          ) {
            if (unit === "mg") calculatedInSameUnit /= 1000;
            else if (unit === "mcg") calculatedInSameUnit /= 1_000_000;
            if (idealUnit === "mg") idealInSameUnit /= 1000;
            else if (idealUnit === "mcg") idealInSameUnit /= 1_000_000;
          } else {
            if (unit === "g") calculatedInSameUnit *= 1000;
            else if (unit === "mcg") calculatedInSameUnit /= 1000;
            if (idealUnit === "g") idealInSameUnit *= 1000;
            else if (idealUnit === "mcg") idealInSameUnit /= 1000;
          }

          const percentage = (calculatedInSameUnit / idealInSameUnit) * 100;
          isBelowThreshold = percentage < 67;
        }
      }
    }

    return {
      key: index,
      name: nutrient.name,
      formattedAmount,
      formattedIdeal,
      isBelowThreshold,
    };
  });
  const calorieForCalc = parseFloat(
    displayedNutrients.find((n) => n.name === "Calories")?.formattedAmount ||
      "0"
  );

  const totalVolume = Math.round(
    selectedIngredients.reduce(
      (total, ingredient) => total + getVolume(ingredient),
      0
    ) * servings
  );

  const kcalPerMl = totalVolume > 0 ? calorieForCalc / totalVolume : 0;

  const printFormulaPDF = async (
    selectedIngredients: SelectedIngredient[],
    servings: number
  ) => {
    setIsGenerating(true);

    try {
      const totalVolume = Math.round(
        selectedIngredients.reduce(
          (total, ingredient) => total + getVolume(ingredient),
          0
        ) * servings
      );

      // Create array of nutrients
      const nutrientArray = displayedNutrients.map((n) => ({
        name: n.name,

        formattedAmount: n.formattedAmount || "",
        formattedIdeal: n.formattedIdeal || "",
      }));

      const blob = await pdf(
        <FormulaDocument
          selectedIngredients={selectedIngredients}
          servings={servings}
          calculatedNutrients={nutrientArray}
          totalVolume={totalVolume}
        />
      ).toBlob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "formula_summary.pdf";
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error generating PDF: ", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <>
      <div
        className="flex flex-col min-h-screen max-w-screen"
        id="formula_calc"
      >
        <Popup
          popUp={popUp}
          setPopUp={setPopUp}
          selectedIngredient={selectedIngredientForPopup?.row || null}
          ingredientType={selectedIngredientForPopup?.type}
          initialAmount={
            selectedIngredientForPopup
              ? (() => {
                  // Find if this ingredient is already in selectedIngredients
                  const existing = selectedIngredients.find(
                    (si) => si.name === selectedIngredientForPopup.name
                  );
                  if (existing) {
                    return parseAmount(existing.amount);
                  }
                  return null;
                })()
              : null
          }
          onAdd={(amount: string, servingType: string) => {
            if (selectedIngredientForPopup) {
              // Check if ingredient already exists in selected list
              const existingIndex = selectedIngredients.findIndex(
                (si) => si.name === selectedIngredientForPopup.name
              );
              if (existingIndex >= 0) {
                // Update existing ingredient
                const updated = [...selectedIngredients];
                updated[existingIndex] = {
                  ...updated[existingIndex],
                  amount: `${amount} ${servingType}`,
                };
                setSelectedIngredients(updated);
              } else {
                // Add new ingredient
                handleAddIngredient(
                  selectedIngredientForPopup,
                  amount,
                  servingType
                );
              }
              setPopUp(false);
              setSelectedIngredientForPopup(null);
            }
          }}
        />
        <p className="text-3xl lg:text-5xl 2xl:text-6xl font-semibold w-fit rounded-[20px] p-2 mt-4 mb-[2dvh]">
          Formula Calculator
        </p>
        <div className="flex flex-col md:flex-row min-h-screen">
          <div className="w-full md:w-[60dvw] flex flex-col mb-10 items-start ">
            <div className="flex flex-col text-black h-[10dvh] rounded ">
              <div className="flex flex-row w-full md:w-[50dvw] relative">
                <input
                  onFocus={() => setSearch(true)}
                  onBlur={() => setSearch(false)}
                  placeholder="Search Formulas and Add Ins"
                  onInput={(e) =>
                    setQuery((e.target as HTMLInputElement).value)
                  }
                  className="w-[70dvw] md:w-[40dvw] rounded-xl border p-1 lg:p-2 2xl:p-3 m-1 text-lg lg:text-xl 2xl:text-2xl"
                />
                <Select
                  onValueChange={(value) => {
                    switch (value) {
                      case "All":
                        setFilter("All");
                        break;
                      case "Powder":
                        setFilter("Powder");
                        break;
                      case "Liquid":
                        setFilter("Liquid");
                        break;
                    }
                  }}
                >
                  <SelectTrigger className="w-[20dvw] md:w-[10dvw] m-1 bg-white rounded-xl text-text xl:text-lg 2xl:text-xl px-2 py-1 lg:px-4 lg:py-2">
                    <SelectValue defaultValue="All" placeholder="All" />
                  </SelectTrigger>
                  <SelectContent className="bg-white w-fit rounded">
                    <SelectGroup className="bg-white">
                      <SelectItem
                        className="w-full bg-white rounded text-text px-4 py-2 hover:bg-primary"
                        value="All"
                      >
                        All
                      </SelectItem>
                      <SelectItem
                        className="w-full bg-white rounded text-text px-4 py-2 hover:bg-primary"
                        value="Powder"
                      >
                        Powder
                      </SelectItem>
                      <SelectItem
                        className="w-full bg-white rounded text-text px-4 py-2 hover:bg-primary"
                        value="Liquid"
                      >
                        Liquid
                      </SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>

                <div
                  className={`${
                    search
                      ? "absolute top-full left-0 bg-white rounded w-full max-h-[40dvh] overflow-y-scroll no-scrollbar shadow-lg z-30 transition-all"
                      : "hidden"
                  }`}
                >
                  {filteredIngredients.map((ingredient, index) => (
                    <>
                      <div
                        className="w-full normal-case font-medium h-fit transition-all duration-200"
                        key={index}
                      >
                        <div className="flex flex-row text-lg lg:text-xl 2xl:text-2xl pl-[1dvw] py-[1dvh] text-start items-center hover:bg-gray-50">
                          <p className="w-[72%]">{ingredient.name}</p>
                          <p className="w-[18%] text-medium">
                            {ingredient.type}
                          </p>
                          <div className="flex flex-row w-[10%] justify-end mr-[2%]">
                            <button
                              onMouseDown={() => handlePlusClick(ingredient)}
                              className="z-30 hover:bg-gray-200 place-self-end w-fit h-fit aspect-square transition-all"
                            >
                              <Plus className="w-8 aspect-square" />
                            </button>
                          </div>
                        </div>
                      </div>
                      <hr className="w-full" />
                    </>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex flex-col h-[40dvh] w-full md:w-[50dvw] border bg-gray rounded-xl relative shadow-lg">
              <div className="w-full sticky top-0">
                <div className="flex flex-row w-full text-lg lg:text-xl 2xl:text-2xl bg-primary-400 font-medium py-[1dvh] rounded-t-xl">
                  <div className="w-[8%] flex justify-center items-center">
                    <button
                      onClick={handleDeleteChecked}
                      className="p-0 m-0 space-x-0 hover:text-red-500 transition-colors"
                      title="Delete selected items"
                    >
                      <Trash2 className="w-8" />
                    </button>
                  </div>
                  <p className="w-3/5">Name</p>
                  <p className="w-1/5">Type</p>
                  <p className="w-1/5">Amount</p>
                  <div className="w-[12%] flex justify-end gap-2"></div>
                </div>
                <hr className="w-full" />
              </div>
              <div className=" h-full overflow-y-scroll no-scrollbar">
                {selectedIngredients.map((selectedIngredient, index) => (
                  <div key={index}>
                    <div className="flex flex-row w-full text-lg lg:text-xl 2xl:text-2xl font-medium py-[1dvh]">
                      <div className="flex justify-center w-[8%]">
                        <button
                          onClick={() => toggleCheck(index)}
                          className="p-0 m-0 space-x-0"
                        >
                          {checked[index] ? (
                            <CheckSquare className="w-8 text-red-500" />
                          ) : (
                            <Square className="w-8" />
                          )}
                        </button>
                      </div>
                      <p className="w-3/5">{selectedIngredient.name}</p>
                      <p className="w-1/5">{selectedIngredient.type}</p>
                      <p className="w-1/5">{selectedIngredient.amount}</p>
                      <div className="flex justify-end w-[12%]">
                        <button
                          onClick={() =>
                            handleEllipsisClick(selectedIngredient)
                          }
                          className="hover:bg-gray-100 rounded p-1"
                        >
                          <Ellipsis className="w-8" />
                        </button>
                      </div>
                    </div>
                    <hr className="w-full" />
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-row h-[30dvh] w-full md:w-[50dvw] border bg-gray rounded-xl relative shadow-lg mt-[5dvh]">
              <div className="flex-1 flex flex-col items-center justify-center">
                <CalorieCircle
                  formattedAmount={
                    displayedNutrients.find(
                      (nutrient) => nutrient.name === "Calories"
                    )?.formattedAmount || "-"
                  }
                  formattedIdeal={
                    displayedNutrients.find(
                      (nutrient) => nutrient.name === "Calories"
                    )?.formattedIdeal || ""
                  }
                  isBelowThreshold={
                    displayedNutrients.find(
                      (nutrient) => nutrient.name === "Calories"
                    )?.isBelowThreshold || false
                  }
                />
                <p className="text-sm mt-2 font-semibold">Calories</p>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center">
                <p className="text-xl md:text-3xl font-bold">
                  {Math.round(
                    selectedIngredients.reduce(
                      (total, ingredient) => total + getVolume(ingredient),
                      0
                    ) * servings
                  )}{" "}
                  mL
                </p>
                <p className="text-sm mt-2 font-semibold">Total Volume</p>
                <p className="text-sm mt-1">
                  {kcalPerMl.toFixed(1)} kcal/mL ({(kcalPerMl * 30).toFixed(1)}{" "}
                  kcal/oz)
                </p>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center">
                <p className="text-xl md:text-3xl font-bold">
                  {
                    displayedNutrients.find(
                      (nutrient) => nutrient.name === "Holliday-Segar"
                    )?.formattedAmount
                  }
                </p>
                <p className="text-sm mt-2 font-semibold">Free Water</p>
              </div>
            </div>
          </div>

          <div className="w-full md:w-[32dvw] flex flex-col">
            <div className="flex flex-row h-[10dvh] md:w-[50dvw]]">
              <p className="text-xl p-1 lg:p-2 2xl:p-3 m-1">
                Servings (per day):
              </p>
              <div className="flex flex-col">
                <input
                  className="w-[20dvw] md:w-[10dvw] rounded-xl border p-1 lg:p-2 2xl:p-3 m-1 text-lg lg:text-xl 2xl:text-2xl shadow-sm"
                  type="number"
                  min="1"
                  placeholder="1"
                  onInput={(e) => {
                    const value = parseFloat(
                      (e.target as HTMLInputElement).value
                    );
                    if (!isNaN(value) && value >= 1) {
                      setServings(value);
                    } else if ((e.target as HTMLInputElement).value === "") {
                      setServings(1);
                    }
                  }}
                />
              </div>
            </div>
            <div>
              <div className="flex flex-col w-full border rounded-xl h-[75dvh] relative shadow-lg mb-10 md:mb-0">
                <div className="sticky top-0">
                  <div className="flex flex-row w-full text-lg lg:text-xl 2xl:text-2xl bg-primary-400 font-medium py-[1dvh] pl-[1dvw] rounded-t-xl">
                    <p className="w-[40%]">Nutrient</p>
                    <p className="w-[30%]">Amount</p>
                    <p className="w-[30%]">DRI</p>
                  </div>
                  <hr className="w-full" />
                </div>
                <div className="h-full overflow-y-scroll no-scrollbar rounded-l-xl">
                  {displayedNutrients.map((nutrient) => (
                    <div key={nutrient.key} className="bg-background">
                      <div className="flex flex-row w-full text-lg lg:text-xl 2xl:text-2xl font-medium py-[1dvh] pl-[1dvw]">
                        <p className="w-[40%] overflow-x-hidden">
                          {nutrient.name}
                        </p>
                        <p
                          className={`w-[30%] bg-white  ${
                            nutrient.isBelowThreshold
                              ? "text-red-500 font-bold"
                              : ""
                          }`}
                        >
                          {nutrient.formattedAmount || "-"}
                        </p>
                        <p className="w-[30%]">{nutrient.formattedIdeal}</p>
                      </div>
                      <hr className="w-full" />
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-end w-full mb-4">
                <button
                  onClick={() => printFormulaPDF(selectedIngredients, servings)}
                  disabled={isGenerating || !hasMixed}
                  className="mt-4 flex w-fit disabled:opacity-50 bg-primary-600 hover:bg-primary-700 transition-all px-2 py-1 lg:px-4 lg:py-2 2xl:px-6 2xl:py-3 text-nowrap items-center rounded text-white text-center text-md lg:text-lg xl:text-xl 2xl:text-2xl font-semibold"
                >
                  {isGenerating ? "Generating..." : "Print Out"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FormulaNeedsCalculator;
