# Pediatric Blue Book

Pediatric Blue Book is a web application designed to help dietitians calculate pediatric nutrient needs and formula recipes more quickly and accurately. The site replaces manual spreadsheet work with a faster and more reliable interface.

The frontend is built with Next.js and TypeScript, deployed on Vercel. The backend uses Supabase for the database, authentication, and storage. The production domain is managed through Namecheap.

## Live Site

Production site: https://pediatricbluebook.com  
Hosted on Vercel.  
Domain purchased and managed through Namecheap.  
Backend database and storage provided by Supabase.

## Purpose

Dietitians often calculate daily nutrient requirements, formula recipes, and nutrition summaries using separate tools or spreadsheets. Pediatric Blue Book centralizes and automates these calculations, making it easier to build accurate nutrition plans for pediatric patients.

## Tech Stack

Framework: Next.js  
Language: TypeScript  
UI: React, Tailwind CSS, shadcn/ui  
Backend: Supabase  
Testing: Jest  
Deployment: Vercel  
Domain: Namecheap  


## Running the Project Locally

### 1. Clone the repository
```
git clone https://github.com/ethanbonsall/Pediatric-Blue-Book.git
cd Pediatric-Blue-Book/web
```

### 2. Install dependencies
```
npm install
```

### 3. Add environment variables
Create a `.env.local` file inside `/web`:

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=optional_for_local
```

### 4. Start the development server
```
npm run dev
```

The app will be available at http://localhost:3000/

## Testing

Tests are written with Jest and stored in `__tests__/`.

Run all tests:
```
npm test
```

Watch mode:
```
npm run test:watch
```

Load tests are written with Artillery and stored in `load-test-login.yml` and `load-test-lookup.yml`. 

Run all tests: 
1. Create account in Pediatric Blue Book and add test credentials LOAD_TEST_USER_EMAIL and LOAD_TEST_USER_PASSWORD to .env.local. Ex: 
```
LOAD_TEST_USER_EMAIL = loadtest@example.com
LOAD_TEST_USER_PASSWORD = testPassword123!
```
3. Install dependencies
```
npm install
```
3. Run the log-in test and generate report 
```
npm run test:load:login
```
4. Run the look-up test and generate report
```
npm run test:load:lookup
```

Results for Log In Load test show that 33% of requests encountered Supabase rate limits but were handled gracefully with 100% eventual success, there was stable performance throughout test, zero failures or errors, and all 120 login attempts were successful. Results for Lookup Load Test show that completion rate is 100%, response times median is 63.4 ms, and p95 is 138 ms. 





